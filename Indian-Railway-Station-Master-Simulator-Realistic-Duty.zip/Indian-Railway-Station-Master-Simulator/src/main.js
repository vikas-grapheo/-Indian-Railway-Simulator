import * as BABYLON from "babylonjs";
import "./style.css";

const canvas = document.getElementById("renderCanvas");
const engine = new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: false, stencil: true, antialias: true });
engine.setHardwareScalingLevel(Math.min(1.5, window.devicePixelRatio || 1));

let scene, train, trainFleet = [], trainMoving = true, cameraMode = "free", selectedPlatform = 1;
let manualMode = true;
const signalAspects = {1:false, 2:false, 3:false};
const routeLocks = {1:false, 2:false, 3:false};
const pointPositions = {1:"normal", 2:"normal", 3:"normal"};
const dutyEvents = [];
let simMinutes = 8 * 60, lastClockUpdate = 0;
let stationBoardTexture = null;
const stationDatabase = [
  {name:"New Delhi",code:"NDLS",trains:[
    {number:"12002",name:"Bhopal Shatabdi Express",from:"New Delhi",to:"Rani Kamlapati",type:"Shatabdi",platform:1,color:"#174b75"},
    {number:"12951",name:"Mumbai Rajdhani Express",from:"Mumbai Central",to:"New Delhi",type:"Rajdhani",platform:2,color:"#b83b32"},
    {number:"12301",name:"Howrah Rajdhani Express",from:"Howrah Jn",to:"New Delhi",type:"Rajdhani",platform:3,color:"#174b75"},
    {number:"22436",name:"Vande Bharat Express",from:"New Delhi",to:"Varanasi Jn",type:"Vande Bharat",platform:1,color:"#e9ecec"},
    {number:"12621",name:"Tamil Nadu Express",from:"New Delhi",to:"Chennai Central",type:"Superfast",platform:2,color:"#174b75"}
  ]},
  {name:"Mumbai Central",code:"MMCT",trains:[
    {number:"12952",name:"Mumbai Rajdhani Express",from:"New Delhi",to:"Mumbai Central",type:"Rajdhani",platform:1,color:"#b83b32"},
    {number:"12951",name:"Mumbai Rajdhani Express",from:"Mumbai Central",to:"New Delhi",type:"Rajdhani",platform:2,color:"#b83b32"},
    {number:"12009",name:"Shatabdi Express",from:"Mumbai Central",to:"Ahmedabad Jn",type:"Shatabdi",platform:3,color:"#174b75"}
  ]},
  {name:"Howrah Junction",code:"HWH",trains:[
    {number:"12301",name:"Howrah Rajdhani Express",from:"Howrah Jn",to:"New Delhi",type:"Rajdhani",platform:1,color:"#174b75"},
    {number:"12302",name:"Howrah Rajdhani Express",from:"New Delhi",to:"Howrah Jn",type:"Rajdhani",platform:2,color:"#174b75"},
    {number:"12019",name:"Shatabdi Express",from:"Howrah Jn",to:"Ranchi Jn",type:"Shatabdi",platform:3,color:"#174b75"}
  ]},
  {name:"Chennai Central",code:"MAS",trains:[
    {number:"12621",name:"Tamil Nadu Express",from:"New Delhi",to:"Chennai Central",type:"Superfast",platform:1,color:"#174b75"},
    {number:"12622",name:"Tamil Nadu Express",from:"Chennai Central",to:"New Delhi",type:"Superfast",platform:2,color:"#174b75"},
    {number:"12007",name:"Shatabdi Express",from:"Chennai Central",to:"Mysuru Jn",type:"Shatabdi",platform:3,color:"#174b75"}
  ]},
  {name:"Rani Kamlapati",code:"RKMP",trains:[
    {number:"12001",name:"Bhopal Shatabdi Express",from:"Rani Kamlapati",to:"New Delhi",type:"Shatabdi",platform:1,color:"#174b75"},
    {number:"12002",name:"Bhopal Shatabdi Express",from:"New Delhi",to:"Rani Kamlapati",type:"Shatabdi",platform:2,color:"#174b75"}
  ]},
  {name:"Jaipur Junction",code:"JP",trains:[
    {number:"12985",name:"Double Decker Express",from:"Jaipur Jn",to:"Delhi Sarai Rohilla",type:"Double Decker",platform:1,color:"#238b4c"},
    {number:"12986",name:"Double Decker Express",from:"Delhi Sarai Rohilla",to:"Jaipur Jn",type:"Double Decker",platform:2,color:"#238b4c"},
    {number:"20977",name:"Vande Bharat Express",from:"Jaipur Jn",to:"Delhi Cantt",type:"Vande Bharat",platform:3,color:"#e9ecec"}
  ]},
  {name:"Lucknow Charbagh",code:"LKO",trains:[
    {number:"12003",name:"Swarn Shatabdi Express",from:"Lucknow NR",to:"New Delhi",type:"Shatabdi",platform:1,color:"#174b75"},
    {number:"12004",name:"Swarn Shatabdi Express",from:"New Delhi",to:"Lucknow NR",type:"Shatabdi",platform:2,color:"#174b75"}
  ]},
  {name:"Bengaluru City",code:"SBC",trains:[
    {number:"22691",name:"Rajdhani Express",from:"KSR Bengaluru",to:"Hazrat Nizamuddin",type:"Rajdhani",platform:1,color:"#b83b32"},
    {number:"22692",name:"Rajdhani Express",from:"Hazrat Nizamuddin",to:"KSR Bengaluru",type:"Rajdhani",platform:2,color:"#b83b32"}
  ]}
];
let selectedStation = stationDatabase[0], selectedService = selectedStation.trains[0];
const ui = id => document.getElementById(id);

function material(name, color, emissive = null) {
  const m = new BABYLON.StandardMaterial(name, scene);
  m.diffuseColor = BABYLON.Color3.FromHexString(color);
  if (emissive) m.emissiveColor = BABYLON.Color3.FromHexString(emissive);
  return m;
}

function box(name, x, y, z, w, h, d, mat) {
  const mesh = BABYLON.MeshBuilder.CreateBox(name, { width:w, height:h, depth:d }, scene);
  mesh.position.set(x,y,z); mesh.material = mat; return mesh;
}

function makeScene() {
  scene = new BABYLON.Scene(engine);
  scene.clearColor = new BABYLON.Color4(0.57, 0.73, 0.84, 1);
  scene.fogMode = BABYLON.Scene.FOGMODE_EXP2;
  scene.fogDensity = 0.0025;
  scene.fogColor = new BABYLON.Color3(0.68,0.78,0.84);

  const hemi = new BABYLON.HemisphericLight("skyLight", new BABYLON.Vector3(0,1,0), scene);
  hemi.intensity = 0.82;
  const sun = new BABYLON.DirectionalLight("sun", new BABYLON.Vector3(-0.4,-1,0.35), scene);
  sun.position = new BABYLON.Vector3(25,40,-20); sun.intensity = 1.05;

  const groundMat = material("ground", "#647d59");
  const concrete = material("concrete", "#aaa99f");
  const platformEdge = material("edge", "#d8c78c");
  const railMat = material("rail", "#6f777b");
  const sleeperMat = material("sleeper", "#4c4036");
  const dark = material("roof", "#263c4c");
  const cream = material("station", "#e4d4ad");
  const red = material("red", "#b83b32");
  const blue = material("blue", "#174b75");
  const white = material("white", "#e9ecec");
  const green = material("green", "#238b4c", "#10451f");
  const amber = material("amber", "#e7b23d");
  const black = material("black", "#20272a");

  // Ground and station forecourt
  box("ground",0,-0.42,0,180,0.5,100,groundMat);
  box("station forecourt",0,-0.13,-31,70,0.12,18,concrete);

  // Platforms and track lanes: tracks run along X.
  const trackZ = [-12, 0, 12, 24];
  trackZ.forEach((z,i) => {
    box(`track bed ${i}`,0,-0.12,z,150,0.16,5.2,black);
    for (let x=-70; x<=70; x+=3) box(`sleeper ${i}-${x}`,x,0.02,z,0.42,0.18,4.5,sleeperMat);
    [-1.45,1.45].forEach(offset => {
      const rail = box(`rail ${i}-${offset}`,0,0.2,z+offset,150,0.22,0.18,railMat);
    });
  });

  // Three island/side platforms
  const platformDefs = [
    {z:-19, label:"PLATFORM 1"},
    {z:6, label:"PLATFORM 2"},
    {z:30, label:"PLATFORM 3"}
  ];
  platformDefs.forEach((p,i) => {
    box(`platform ${i}`,0,0.12,p.z,145,0.55,7.5,concrete);
    box(`yellow tactile edge ${i}`,0,0.42,p.z+3.42,145,0.08,0.48,platformEdge);
    // benches, lamps and signs
    for (let x=-55; x<=55; x+=27) {
      box(`bench seat ${i}-${x}`,x,0.95,p.z-1.1,2.5,0.18,0.65,blue);
      box(`bench back ${i}-${x}`,x,1.45,p.z-1.38,2.5,0.9,0.16,blue);
      box(`lamp pole ${i}-${x}`,x,3.0,p.z+1.2,0.18,5.5,0.18,black);
      box(`lamp head ${i}-${x}`,x,5.8,p.z+1.2,1.0,0.18,0.4,white);
    }
    box(`platform sign ${i}`, -37,4.0,p.z-2.0, 9,1.8,0.3,blue);
    const sign = BABYLON.MeshBuilder.CreatePlane(`platform text ${i}`, {width:7.8,height:1.1}, scene);
    sign.position.set(-37,4.05,p.z-1.82); sign.rotation.y = 0;
    const dt = new BABYLON.DynamicTexture(`sign texture ${i}`, {width:512,height:128}, scene, false);
    dt.drawText(p.label, 20, 84, "bold 54px Arial", "white", "#174b75", true);
    const sm = new BABYLON.StandardMaterial(`sign material ${i}`,scene); sm.diffuseTexture=dt; sm.emissiveColor=new BABYLON.Color3(0.6,0.6,0.6); sign.material=sm;
  });

  // Station building at the far side
  box("station building",0,4.1,-31,78,8,9,cream);
  box("station roof",0,8.4,-31,82,0.55,11,dark);
  for(let x=-32;x<=32;x+=16){
    box(`building window ${x}`,x,4.5,-26.38,6,2.5,0.18,blue);
    box(`building door ${x}`,x+5,2.0,-26.35,2.2,3.5,0.2,red);
  }
  box("station name board",0,7.1,-25.9,28,1.8,0.4,blue);
  const board = BABYLON.MeshBuilder.CreatePlane("station name", {width:25,height:1.35},scene);
  board.position.set(0,7.1,-25.65);
  const boardTex = new BABYLON.DynamicTexture("station board texture",{width:1024,height:128},scene,false);
  stationBoardTexture = boardTex;
  boardTex.drawText("NEW DELHI  |  नई दिल्ली",25,88,"bold 68px Arial","white","#174b75",true);
  const boardMat = new BABYLON.StandardMaterial("board mat",scene); boardMat.diffuseTexture=boardTex; boardMat.emissiveColor=new BABYLON.Color3(0.7,0.7,0.7); board.material=boardMat;

  // Overhead electric gantries
  for(let x=-60;x<=60;x+=30){
    box(`gantry post L ${x}`,x,7,-7,0.35,14,0.35,black);
    box(`gantry post R ${x}`,x,7,32,0.35,14,0.35,black);
    box(`gantry beam ${x}`,x,13,12,0.35,0.35,40,black);
    box(`wire ${x}`,x,11.8,12,30,0.07,0.07,railMat);
  }

  // Signal props for visual gameplay only
  [-12,0,12,24].forEach((z,i)=>{
    box(`signal mast ${i}`,-48,3.2,z+3,0.22,6.4,0.22,black);
    box(`signal head ${i}`,-48,6.2,z+3,1.0,1.6,0.7,black);
    const lamp = BABYLON.MeshBuilder.CreateSphere(`signal lamp ${i}`,{diameter:0.48},scene);
    lamp.position.set(-48,6.55,z+2.6); lamp.material=i===0?green:red;
  });

  // Train model on track 1, moving along X
  train = new BABYLON.TransformNode("passenger train",scene);
  const loco = box("locomotive body",0,1.35,0,11,2.2,3.0,blue); loco.parent=train;
  const roof = box("locomotive roof",0,2.55,0,9.8,0.35,3.1,white); roof.parent=train;
  const nose = box("locomotive nose",5.25,1.25,0,1.0,1.65,3.0,red); nose.parent=train;
  const stripe = box("loco stripe",0,1.55,1.53,9.8,0.28,0.08,amber); stripe.parent=train;
  for(let c=0;c<5;c++){
    const coach = box(`coach ${c}`, -7.5-c*10,1.25,0,9.2,2.5,3.0,cream); coach.parent=train;
    const coachRoof = box(`coach roof ${c}`,-7.5-c*10,2.58,0,9.3,0.22,3.05,blue); coachRoof.parent=train;
    for(let w=-2;w<=2;w++){
      const win=box(`coach window ${c}-${w}`,-7.5-c*10+w*1.55,1.65,1.53,1.1,0.65,0.08,blue); win.parent=train;
    }
  }
  // Wheels
  for(let car=0;car<6;car++){
    const cx=car===0?0:-7.5-(car-1)*10;
    for(const wx of [-3.7,3.7]){
      const wheel=BABYLON.MeshBuilder.CreateCylinder(`wheel ${car}-${wx}`,{diameter:0.9,height:0.25,tessellation:16},scene);
      wheel.rotation.z=Math.PI/2; wheel.position.set(cx+wx,0.62,1.58); wheel.parent=train; wheel.material=black;
    }
  }
  train.position.set(-55,0,-12);

  // Build two additional independent train sets from the same detailed 3D model.
  // Each train runs on its own track and follows an automatic approach-stop-depart cycle.
  function duplicateTrain(source, name) {
    const node = new BABYLON.TransformNode(name, scene);
    scene.meshes.filter(mesh => mesh.parent === source).forEach(mesh => {
      const copy = mesh.clone(`${name}-${mesh.name}`, node);
      copy.parent = node;
    });
    return node;
  }
  const train2 = duplicateTrain(train, "Vande Bharat-style demo train");
  const train3 = duplicateTrain(train, "Express demo train");
  trainFleet = [
    {node:train, label:"Bhopal Shatabdi Express", number:"12002", z:-12, x:-82, phase:"waiting", dwell:0, platform:1},
    {node:train2, label:"Vande Bharat Express", number:"22436", z:0, x:-82, phase:"waiting", dwell:0, platform:2},
    {node:train3, label:"Mumbai Rajdhani Express", number:"12951", z:12, x:-82, phase:"waiting", dwell:0, platform:3}
  ];
  trainFleet.forEach((item, i) => {
    item.node.position.set(item.x, 0, item.z);
    // Add cab windows and front headlights to each locomotive for a more readable 3D model.
    const cabGlass = box(`cab glass ${i}`, 4.65, 1.85, 1.56, 1.1, 0.65, 0.08, blue);
    cabGlass.parent = item.node;
    const lamp = BABYLON.MeshBuilder.CreateSphere(`headlight ${i}`, {diameter:0.34, segments:12}, scene);
    lamp.position.set(5.82,1.15,1.58); lamp.material=amber; lamp.parent=item.node;
  });

  // Cameras
  const freeCam = new BABYLON.ArcRotateCamera("freeCamera",-Math.PI/2,1.12,72,new BABYLON.Vector3(0,0,2),scene);
  freeCam.lowerRadiusLimit=24; freeCam.upperRadiusLimit=115; freeCam.wheelPrecision=35;
  freeCam.attachControl(canvas,true);
  const fpCam = new BABYLON.UniversalCamera("firstPerson",new BABYLON.Vector3(0,2.1,-21),scene);
  fpCam.setTarget(new BABYLON.Vector3(20,1.5,-12));
  fpCam.speed=0.65; fpCam.inertia=0.7; fpCam.angularSensibility=3500;
  fpCam.attachControl(canvas,true);
  fpCam.keysUp=[]; fpCam.keysDown=[]; fpCam.keysLeft=[]; fpCam.keysRight=[];
  scene.activeCamera=freeCam;

  // Small decorative trees
  const trunkMat=material("trunk","#66513c"), leafMat=material("leaves","#315b39");
  for(let x=-65;x<=65;x+=18){
    [-39,42].forEach(z=>{
      const trunk=box(`tree trunk ${x}-${z}`,x,1.4,z,0.8,2.8,0.8,trunkMat);
      const crown=BABYLON.MeshBuilder.CreateSphere(`tree crown ${x}-${z}`,{diameter:4.5,segments:8},scene);
      crown.position.set(x,3.6,z); crown.material=leafMat;
    });
  }

  scene.onBeforeRenderObservable.add(()=>{
    const dt=engine.getDeltaTime()/1000;
    if(trainMoving){
      trainFleet.forEach(item => {
        if(manualMode) {
          if(item.phase === "approach" && signalAspects[item.platform]) {
            item.x += dt * 5.2;
            if(item.x >= 0) { item.x = 0; item.phase = "halt"; item.dwell = 0; }
          } else if(item.phase === "depart") {
            item.x += dt * 6.5;
            if(item.x > 82) { item.x = -82; item.phase = "waiting"; }
          }
        } else if(item.phase === "approach") {
          item.x += dt * 5.2;
          if(item.x >= 0) { item.x = 0; item.phase = "halt"; item.dwell = 0; }
        } else if(item.phase === "halt") {
          item.dwell += dt;
          if(item.dwell >= 8) item.phase = "depart";
        } else {
          item.x += dt * 5.2;
          if(item.x > 82) { item.x = -82; item.phase = "approach"; }
        }
        item.node.position.x = item.x;
      });
    }
    const now=performance.now();
    if(now-lastClockUpdate>1000){
      simMinutes += 1; lastClockUpdate=now;
      const hh=String(Math.floor(simMinutes/60)%24).padStart(2,"0");
      const mm=String(simMinutes%60).padStart(2,"0");
      ui("simTime").textContent=`${hh}:${mm}`;
      const current = trainFleet.map(t => `${t.number}: ${t.phase === "waiting" ? "WAITING" : t.phase === "approach" ? "APPROACHING" : t.phase === "halt" ? "AT PLATFORM" : "DEPARTING"}`).join(" · ");
      const board = ui("trafficBoard"); if(board) board.textContent=current;
      const primary = trainFleet[0];
      const phaseText = primary.phase === "waiting" ? "Waiting for signal" : primary.phase === "approach" ? "Approaching" : primary.phase === "halt" ? "At platform · held" : "Departing";
      if(ui("movementTitle")) ui("movementTitle").textContent = `${selectedService.name} · ${phaseText}`;
    }
  });

  return scene;
}

function fillTrainOptions(){
  const select=ui("trainSelect"); select.innerHTML="";
  selectedStation.trains.forEach((t,i)=>{const opt=document.createElement("option");opt.value=String(i);opt.textContent=`${t.number} · ${t.name}`;select.appendChild(opt);});
  selectedService=selectedStation.trains[0]; select.value="0"; applySelectedService();
}
function applySelectedService(){
  selectedService=selectedStation.trains[Number(ui("trainSelect").value)||0];
  ui("activeTrain").textContent=`${selectedService.number} ${selectedService.name}`;
  ui("trainInfo").textContent=`${selectedService.number} · ${selectedService.from} → ${selectedService.to}`;
  ui("movementTitle").textContent=`${selectedService.name} ${trainMoving?"ready":"simulation paused"}`;
  ui("movementSub").textContent=`Platform ${selectedPlatform} · ${selectedService.type} service`;
  selectedPlatform=selectedService.platform;
  let assigned = trainFleet.find(t => t.number === selectedService.number);
  if(!assigned){ assigned=trainFleet[0]; assigned.number=selectedService.number; assigned.label=selectedService.name; }
  if(assigned){ assigned.number=selectedService.number; assigned.label=selectedService.name; assigned.platform=selectedPlatform; assigned.z=[-12,0,12][(selectedPlatform-1)%3]; assigned.node.position.z=assigned.z; }
  document.querySelectorAll(".route-btn[data-platform]").forEach(b=>{b.classList.toggle("selected",Number(b.dataset.platform)===selectedPlatform);});
  ui("routeNote").textContent=`${selectedService.number} ${selectedService.name} · Platform ${selectedPlatform} · ${selectedService.from} to ${selectedService.to}. Timings are not live.`;
  if(train){train.position.z=[-12,0,12][(selectedPlatform-1)%3];}
  updateCommandPanel();
  toast(`Selected ${selectedService.number} ${selectedService.name}`);
}
function applyStation(){
  const idx=Number(ui("stationSelect").value)||0; selectedStation=stationDatabase[idx];
  ui("stationStatus").textContent=`${selectedStation.name.toUpperCase()} (${selectedStation.code})`;
  if(stationBoardTexture){stationBoardTexture.clear();stationBoardTexture.drawText(`${selectedStation.name.toUpperCase()}  |  ${selectedStation.code}`,25,88,"bold 58px Arial","white","#174b75",true);}
  fillTrainOptions();
  toast(`${selectedStation.name} selected`);
}
stationDatabase.forEach((st,i)=>{const opt=document.createElement("option");opt.value=String(i);opt.textContent=`${st.name} (${st.code})`;ui("stationSelect").appendChild(opt);});
ui("stationSelect").addEventListener("change",applyStation);
ui("trainSelect").addEventListener("change",applySelectedService);

function selectedFleetTrain(){
  return trainFleet.find(t => t.number === selectedService.number) || trainFleet[0];
}
function logDuty(message){
  const hh=String(Math.floor(simMinutes/60)%24).padStart(2,"0");
  const mm=String(simMinutes%60).padStart(2,"0");
  dutyEvents.unshift(`${hh}:${mm} · ${message}`);
  if(dutyEvents.length>5) dutyEvents.pop();
  const log=ui("dutyLog"); if(log) log.textContent=dutyEvents.join("\n");
}
function updateCommandPanel(){
  const aspect = signalAspects[selectedPlatform] ? "GREEN" : "RED";
  ui("signalState").textContent = `P${selectedPlatform} SIGNAL: ${aspect}`;
  ui("signalState").className = `signal-state ${signalAspects[selectedPlatform] ? "is-green" : "is-red"}`;
  const item = selectedFleetTrain();
  const state = item ? item.phase.toUpperCase() : "NO TRAIN";
  ui("commandNote").textContent = `${item ? item.number + " · " + item.label : "No mapped demo train"} · ${state}`;
  ui("signalBtn").textContent = signalAspects[selectedPlatform] ? "🔴 Set signal RED" : "🟢 Set signal GREEN";
  const routeStatus=ui("interlockingStatus");
  if(routeStatus){
    routeStatus.textContent=routeLocks[selectedPlatform] ? `ROUTE LOCKED · ${signalAspects[selectedPlatform]?"SIGNAL GREEN":"SIGNAL RED"}` : "ROUTE NOT SET · SIGNAL RED";
    routeStatus.className=`signal-state ${routeLocks[selectedPlatform] && signalAspects[selectedPlatform]?"is-green":"is-red"}`;
  }
  const routeBtn=ui("routeSetBtn"); if(routeBtn) routeBtn.textContent=routeLocks[selectedPlatform]?"🔓 Release route lock":"🔒 Set & lock route";
}

makeScene();
ui("stationStatus").textContent=`${selectedStation.name.toUpperCase()} (${selectedStation.code})`;
fillTrainOptions();
updateCommandPanel();
engine.runRenderLoop(()=>{ if(scene) scene.render(); });
window.addEventListener("resize",()=>engine.resize());

function toast(message){
  const el=ui("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2400);
}

ui("startBtn").addEventListener("click",()=>{
  ui("startScreen").classList.add("hidden");
  toast("Duty started · Welcome, Station Master!");
});
ui("cameraBtn").addEventListener("click",()=>{
  if(cameraMode==="free"){
    cameraMode="first"; scene.activeCamera=scene.cameras.find(c=>c.name==="firstPerson");
    ui("cameraBtn").textContent="◉ Free camera"; toast("First-person view enabled");
  } else {
    cameraMode="free"; scene.activeCamera=scene.cameras.find(c=>c.name==="freeCamera");
    toast("Free camera enabled");
  }
});
ui("trainBtn").addEventListener("click",()=>{
  trainMoving=!trainMoving;
  ui("trainBtn").textContent=trainMoving?"Ⅱ Pause simulation":"▶ Resume simulation";
  ui("movementTitle").textContent=`${selectedService.name} ${trainMoving?"ready":"simulation paused"}`;
  toast(trainMoving?"Simulation resumed":"Simulation paused");
});
ui("hornBtn").addEventListener("click",()=>toast("🔔 Demo locomotive horn"));
ui("announceBtn").addEventListener("click",()=>{
  const msg=`यात्रियों कृपया ध्यान दें। ${selectedStation.name} स्टेशन पर गाड़ी संख्या ${selectedService.number}, ${selectedService.name}, प्लेटफॉर्म संख्या ${selectedService.platform} आने वाली है। यह सिमुलेशन की घोषणा है।`;
  if("speechSynthesis" in window){speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(msg));}
  toast("Station announcement played");
});
ui("routeSetBtn").addEventListener("click",()=>{
  const item=trainFleet.find(t=>t.platform===selectedPlatform && t.phase!=="waiting");
  if(routeLocks[selectedPlatform]){
    signalAspects[selectedPlatform]=false;
    routeLocks[selectedPlatform]=false;
    logDuty(`P${selectedPlatform} route released; signal returned to RED`);
    toast(`Platform ${selectedPlatform} route released`);
  } else {
    const occupied=trainFleet.some(t=>t.platform===selectedPlatform && t.phase==="halt");
    const anotherLocked=Object.keys(routeLocks).some(p=>Number(p)!==selectedPlatform && routeLocks[p] && signalAspects[p]);
    if(occupied){toast("Route unavailable: platform occupied by a stopped train"); return;}
    if(anotherLocked){toast("Interlocking: another route is active. Release it first."); return;}
    routeLocks[selectedPlatform]=true;
    pointPositions[selectedPlatform]=ui("pointsSelect").value;
    logDuty(`P${selectedPlatform} route set (${pointPositions[selectedPlatform]}) and locked`);
    toast(`Platform ${selectedPlatform} route set and locked`);
  }
  updateCommandPanel();
});
ui("signalBtn").addEventListener("click",()=>{
  if(!routeLocks[selectedPlatform] && !signalAspects[selectedPlatform]){toast("Interlocking prevents clearing signal: set and lock a route first"); return;}
  signalAspects[selectedPlatform] = !signalAspects[selectedPlatform];
  const item = selectedFleetTrain();
  if(!signalAspects[selectedPlatform] && item && item.platform===selectedPlatform && item.phase==="approach") item.phase="waiting";
  if(signalAspects[selectedPlatform] && item && item.platform===selectedPlatform && item.phase==="waiting") item.phase="approach";
  updateCommandPanel();
  logDuty(`P${selectedPlatform} simulated signal ${signalAspects[selectedPlatform]?"GREEN":"RED"}`);
  toast(`Platform ${selectedPlatform} game signal ${signalAspects[selectedPlatform]?"GREEN":"RED"}`);
});
ui("holdBtn").addEventListener("click",()=>{
  const item=selectedFleetTrain();
  if(!item) return;
  if(item.phase==="approach" || item.phase==="depart") item.phase="waiting";
  else if(item.phase==="halt") item.phase="waiting";
  updateCommandPanel(); logDuty(`${item.number} held by Station Master`); toast(`${item.number} held by Station Master`);
});
ui("dispatchBtn").addEventListener("click",()=>{
  const item=selectedFleetTrain();
  if(!item) return;
  if(item.phase==="halt" && signalAspects[item.platform] && routeLocks[item.platform]) { item.phase="depart"; logDuty(`${item.number} dispatched from P${item.platform}`); toast(`${item.number} departure authorised in game`); }
  else if(item.phase==="halt") toast("Set this platform signal GREEN before dispatching the train");
  else if(item.phase==="waiting" && signalAspects[item.platform] && routeLocks[item.platform]) { item.phase="approach"; logDuty(`${item.number} accepted on P${item.platform}`); toast(`${item.number} approaching on green game signal`); }
  else if(item.phase==="waiting") toast("Set the platform signal GREEN before allowing this demo train to approach");
  else toast("Selected train is already moving or approaching");
  updateCommandPanel();
});

document.querySelectorAll(".route-btn[data-platform]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    selectedPlatform=Number(btn.dataset.platform);
    const assigned=selectedFleetTrain();
    if(assigned){assigned.platform=selectedPlatform;assigned.z=[-12,0,12][(selectedPlatform-1)%3];assigned.node.position.z=assigned.z;}
    document.querySelectorAll(".route-btn[data-platform]").forEach(b=>b.classList.remove("selected"));
    btn.classList.add("selected");
    ui("routeNote").textContent=`Platform ${selectedPlatform} selected. Signal and dispatch commands apply to this platform.`;
    updateCommandPanel();
    toast(`Platform ${selectedPlatform} selected`);
  });
});
