# Indian Railway Station Master Simulator

An early Android-first 3D railway station game prototype built with Babylon.js, Vite and Capacitor.

## Current prototype
- Landscape-oriented Android activity and responsive game HUD
- 3D demo station environment with 3 platforms and 4 tracks
- Moving passenger train prototype
- Free camera and first-person camera toggle
- Demo platform selection UI
- Hindi text-to-speech announcement (device voice availability varies)
- Pause/resume train and demo horn feedback
- GitHub Actions workflow to build a debug APK

## Important
This is an entertainment prototype, not a railway training tool. The route and signal controls are illustrative UI only and are not connected to real railway signalling or interlocking systems. Station layout, branding, train liveries and station names are placeholders and should be checked for permissions/accuracy before public release.

## Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

## Build Android APK
The GitHub Actions workflow `.github/workflows/build-android-apk.yml` installs dependencies, builds the web app, creates the Capacitor Android project and uploads a debug APK as an Actions artifact.

1. Upload the project to a GitHub repository.
2. Open the **Actions** tab.
3. Select **Build Indian Railway Simulator APK**.
4. Tap **Run workflow** (or push to `main`).
5. When complete, open the run and download `Indian-Railway-Simulator-debug-apk`.

The generated APK is a debug build for testing. A release APK/AAB requires signing configuration before publishing.
