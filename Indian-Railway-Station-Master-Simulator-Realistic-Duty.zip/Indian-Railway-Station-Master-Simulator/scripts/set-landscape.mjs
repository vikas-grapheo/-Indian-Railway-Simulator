import fs from "node:fs";
import path from "node:path";

const manifest = path.join("android", "app", "src", "main", "AndroidManifest.xml");
if (!fs.existsSync(manifest)) {
  throw new Error(`Android manifest not found: ${manifest}`);
}
let xml = fs.readFileSync(manifest, "utf8");
if (/android:screenOrientation=/.test(xml)) {
  xml = xml.replace(/android:screenOrientation="[^"]*"/, 'android:screenOrientation="landscape"');
} else {
  xml = xml.replace(/(<activity\b)/, '$1\n            android:screenOrientation="landscape"');
}
fs.writeFileSync(manifest, xml);
console.log("Configured Android activity for landscape orientation.");
